// Generated Wysicraft server handlers. Install on the server; /reload after replacement.
(() => {
const API = Java.loadClass('com.wysicraft.runtime.api.WysicraftApi');
const projectId = "kube_bridge";
API.clearKubeHandlers(projectId);
(() => {
function on_click(event) {
  var clicks = Number(event.state.get('clicks') || 0) + 1;
  event.state.set('clicks', String(clicks));
  event.message('KubeJS received your Wysicraft click!');
  event.ui.setText('status', 'Server clicks: ' + clicks);
  event.runCommand('me tested the Wysicraft bridge');
  // Replace the command above with portal if your server provides it.
}

API.registerKubeHandler(projectId, "16f3334ae983d37dba52e5eb8c7e8b968d8354d7132afabae2c6e898459361dd", (context, value) => {
  const player = context.player();
  const ui = {setItem: (id, item) => API.setItem(player, id, String(item)), setItems: (id, items) => API.setItems(player, id, JSON.stringify(items)), showPlayerInventory: id => API.showPlayerInventory(player, id), setText: (id, text) => API.setText(player, id, String(text)), setValue: (id, value) => API.setValue(player, id, String(value)), setVisible: (id, visible) => API.setVisible(player, id, !!visible), setEnabled: (id, enabled) => API.setEnabled(player, id, !!enabled), setVariable: (name, value) => API.setVariable(player, name, String(value)), getVariable: name => context.state().get(String(name)), open: id => API.openUi(player, String(id).includes(':') ? String(id) : projectId + ':' + id), close: () => API.closeProject(player, projectId)};
  const event = {player: player, server: player.getServer(), value: String(context.state().getOrDefault('event_value', '')), ui: ui, runCommand: command => API.runCommand(player, String(command)), message: text => API.message(player, String(text)), state: {get: ui.getVariable, set: ui.setVariable}};
  try { on_click(event); } catch (error) { const line=Number(error.lineNumber || 0); const location=line>=7 && line<16 ? ' line '+(line-7+1) : ''; throw new Error("Wysicraft script scripts/server/test.js :: on_click" + location + ': ' + error); }
});
})();

console.info('Wysicraft: registered 1 handlers for ' + projectId);
})();
